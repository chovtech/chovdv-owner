<?php

    // Retrieve the raw JSON data from the request body
    $webhookPayload = file_get_contents("php://input");
    
    // Decode the JSON data into a PHP array
    $webhookData = json_decode($webhookPayload, true);
    
    // Check if the decoding was successful
    if ($webhookData !== null) {
        // Access the specific data you need
        $eventType = $webhookData['eventType'];
        $transactionReference = $webhookData['eventData']['transactionReference'];
        $amountPaid = $webhookData['eventData']['amountPaid'];
        $paymentStatus = $webhookData['eventData']['paymentStatus'];
        $customerName = $webhookData['eventData']['customer']['name'];
        $customerEmail = $webhookData['eventData']['customer']['email'];
    
        // Process the data further as needed
    
        // For example, log the details
        $logMessage = "Webhook received - EventType: $eventType, TransactionReference: $transactionReference, AmountPaid: $amountPaid, PaymentStatus: $paymentStatus, Customer: $customerName ($customerEmail)";
        error_log($logMessage, 3, "webhook_log.txt");
    } else {
        // Handle the case where JSON decoding failed
        error_log("Failed to decode JSON data from webhook", 3, "webhook_log.txt");
    }
    
    // Send a response (optional)
    header("Content-Type: application/json");
    echo json_encode(["status" => "success"]);
    
?>
